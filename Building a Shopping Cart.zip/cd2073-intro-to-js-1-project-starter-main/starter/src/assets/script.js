
const products = [ /*Open array that contains products*/

{ /* First product in array*/
  name: "Sword", /*Initialize Name of object*/
  price: 2.50, /*Initialize Price of object*/
  quantity: 0, /*Initialize Quantity of object*/
  productId: 1, /*Initialize productId of object*/
  image: "images/Sword.img.jpg" /*Image of Sword to present in shop*/
},

{ /* Second product in array*/
  name: "Axe", /*Initialize Name of object*/
  price: 3.50, /*Initialize Price of object*/
  quantity: 0, /*Initialize Quantity of object*/
  productId: 2, /*Initialize productId of object*/
  image: "images/Axe.img.jpg" /*Image of Axe to present in shop*/
},

{ /* Third product in array*/
  name: "Bow", /*Initialize Name of object*/
  price: 5.00, /*Initialize Price of object*/
  quantity: 0, /*Initialize Quantity of object*/
  productId: 3, /*Initialize productId of object*/
  image: "images/Bow.img.jpg" /*Image of Bow to present in shop*/
}
] /*Closes array that contains products */

let cart = []; /*Create array that functions as the online Shopping Cart
                  that products will be added and removed from */

/*Takes product from products array based on productId literal and adds the product to the cart array*/                  
function addProductToCart(productId) {
  const product = products.find(p => p.productId === productId); /*Find product in products array based on productId */
  if (!product) { /*Check if productId is not found in the products array*/
    return; /*Ends function */
  }
  const productInCart = cart.find(item => item.productId === productId); /*Find product in cart based on productId */
  if (productInCart) { /*Check if product is found in cart array */
    productInCart.quantity += 1;/*If in cart, increases quantity of product in cart by 1 */
  } else {
    product.quantity += 1; /*Increase quantity of object by 1*/
    cart.push(product); /*Adds product to cart if not in cart */
  }
}

/*Increase quantity of product in cart based on the associated productId */
function increaseQuantity(productId) {
  const productInCart = cart.find(item => item.productId === productId); /*Finds product in cart by productId */
  if (productInCart) { /*Check if product is in cart */
    productInCart.quantity += 1; /**If product is in cart, increase quantity of product by 1 */
  }
}

/*Decrease quantity of product in cart based on the associated productId */
function decreaseQuantity(productId) {
  const productInCart = cart.find(item => item.productId === productId);/*Finds product in cart by productId */
  if (productInCart) { /*Check if product is in cart */
    productInCart.quantity -= 1; /*If product is in cart, decrease quantity of product by 1 */
    if (productInCart.quantity === 0) { /*Checks if quantity of product in cart is equal to 0 */
      removeProductFromCart(productId); /*Removes product from cart array */
    }
  } 
}

/*Remove product from cart array based on productId */
function removeProductFromCart(productId) { 
  const product = cart.find(p => p.productId === productId); /*Finds product in cart by productId */
  product.quantity = 0; /*Reinitialize quantity of product as 0 */
  cart.splice(product, 1); /*Remove product from cart array */
  return cart; //Return cart array
}

/*Intializes totalPaid variable as 0 */
let totalPaid = 0;

/*Caluclates total value of products in cart */
function cartTotal() {
  let total = 0; /*Initializes total variable as 0 */
  for (let i = 0; i < cart.length; i++) { /*Iterates through cart array */
    total += cart[i].quantity * cart[i].price; /*Adds value to total variable for each product in cart 
                                                  iterated over by multiplying product price by product quantity */
  }
  return total /*Return total variable */
}

/*Remove all products from cart */
function emptyCart() {
  cart = []; /*Initializes cart as having no products */
  return cart; //Return cart array
}

/*Carry out payment process for shop based on the amount paid by customer*/
function pay(amount) {
  const totalCost = cartTotal(); /*Create object with value equal to cartTotal function */
  const change = amount - totalCost; /*Create variable with value of the amount minus the totalCost*/
  if (change >= 0) { /*Checks if change variable is great or equal to 0 */
    totalPaid = 0; /*Reinitializes totalPaid as 0 */
    emptyCart(); /*Calls emptyCart function */
  }
  return change; /*Return value of change variable */
}

module.exports = {
   products,
   cart,
   addProductToCart,
   increaseQuantity,
   decreaseQuantity,
   removeProductFromCart,
   cartTotal,
   pay, 
   emptyCart,
   /* Uncomment the following line if completing the currency converter bonus */
   // currency
}